<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FuncionarioContactos extends Model
{
    //
}
