<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\FuncionarioContactos;
use Faker\Generator as Faker;

$factory->define(FuncionarioContactos::class, function (Faker $faker) {
    return [
        //
    ];
});
