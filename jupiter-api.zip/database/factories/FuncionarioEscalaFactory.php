<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\FuncionarioEscala;
use Faker\Generator as Faker;

$factory->define(FuncionarioEscala::class, function (Faker $faker) {
    return [
        //
    ];
});
