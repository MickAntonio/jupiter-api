<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Localizacoes;
use Faker\Generator as Faker;

$factory->define(Localizacoes::class, function (Faker $faker) {
    return [
        //
    ];
});
