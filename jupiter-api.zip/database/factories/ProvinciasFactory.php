<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Provincias;
use Faker\Generator as Faker;

$factory->define(Provincias::class, function (Faker $faker) {
    return [
        //
    ];
});
