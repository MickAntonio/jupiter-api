<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Vans;
use Faker\Generator as Faker;

$factory->define(Vans::class, function (Faker $faker) {
    return [
        //
    ];
});
