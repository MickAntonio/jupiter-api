<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Viagens;
use Faker\Generator as Faker;

$factory->define(Viagens::class, function (Faker $faker) {
    return [
        
    ];
});
